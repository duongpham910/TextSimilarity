package View;

import Algorithms.Out_of_place;
import Model.Gram;
import Model.GramComparatorTFIDF;
import Utils.Praser;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Duong Pham on 11/11/2016.
 */
public class ArticleTab extends JPanel implements ActionListener {

    public JTextField txtUrl_original=new JTextField(30);
    public JTextField txtUrl_altered=new JTextField(30);
    public JButton btnCheck = new JButton("Check");
    public JButton btnContent = new JButton("Get content");
    public Out_of_place out_of_place=new Out_of_place();
    public ArrayList<Gram> lOriginal;
    public ArrayList<Gram> lAltered;

    public String original_text = "Original text";
    public String altered_text = "Rewrite text";

    public JTextPane tpOriginal = new JTextPane();
    public JTextPane tpAltered = new JTextPane();
    public JTextPane tpResult =new JTextPane();

    public JLabel txtOriginal=new JLabel("");
    public JLabel txtAltered=new JLabel("");

    public ArrayList<Gram> list_gram_similar = new ArrayList<Gram>();
    public ArrayList<Gram> list_gram_similar_alt = new ArrayList<Gram>();

    public String temp_document;
    public String temp_provider;
    public StringBuilder sbResult;

    public int tag_counter=1;

    public int[] positions_highlight ;
    public int[] positions_highlight_altered;

    public StyledDocument doc_altered;
    public StyledDocument doc_origin;
    public Document temp_blank = new DefaultStyledDocument();


    public Praser praser=new Praser();

    public ArticleTab(){
        setLayout(new BorderLayout());

        Font f = tpOriginal.getFont();
        Font f2 = new Font(f.getFontName(), f.getStyle(), f.getSize()+3);

        JPanel p1=new JPanel();
        p1.setLayout(new GridBagLayout());
        btnCheck.addActionListener(this);
        btnContent.addActionListener(this);
        GridBagLayout gridBagLayout=new GridBagLayout();
        GridBagConstraints gridBagConstraints;

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=0;
        p1.add(new JLabel("Link original:"),gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=1;
        p1.add(txtUrl_original,gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=2;
        p1.add(new JLabel("Link altered:"),gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=3;
        p1.add(txtUrl_altered,gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=4;
        p1.add(btnContent,gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridx=5;
        p1.add(btnCheck,gridBagConstraints);

        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=1;
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridwidth=3;
        gridBagConstraints.insets=new Insets(5,5,5,5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        txtOriginal.setFont(f2);
        p1.add(txtOriginal,gridBagConstraints);


        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridy=1;
        gridBagConstraints.gridx=4;
        gridBagConstraints.gridwidth=3;
        gridBagConstraints.insets=new Insets(5,5,5,5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        txtAltered.setFont(f2);
        p1.add(txtAltered,gridBagConstraints);

        JPanel p2=new JPanel(new GridLayout(0,2));
        tpOriginal.setFont(f2);
        tpAltered.setFont(f2);
        p2.add(new JScrollPane(tpOriginal));
        p2.add(new JScrollPane(tpAltered));


        JPanel p3=new JPanel();
        p3.setLayout(gridBagLayout);
        gridBagConstraints=new GridBagConstraints();
        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=1;
        gridBagConstraints.gridwidth=2;
        gridBagConstraints.insets=new Insets(5,5,5,5);
        JScrollPane jp=new JScrollPane(tpResult);
        tpResult.setFont(f2);
        jp.setPreferredSize(new Dimension(1280, 150));
        p3.add(jp,gridBagConstraints);

        this.add(p1,"North");
        this.add(p2,"Center");
        this.add(p3,"South");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==btnContent){
            String url_original=txtUrl_original.getText();
            String url_altered=txtUrl_altered.getText();
            if(checkUrl(url_original)){
                original_text=getContent(temp_provider,url_original);
                tpOriginal.setText(original_text);
                lOriginal = out_of_place.createGram(original_text,1);
                positions_highlight=new int[original_text.length()];
                doc_origin = tpOriginal.getStyledDocument();
                txtOriginal.setText(praser.getTitle(url_original));
            }else{
                JOptionPane.showMessageDialog(this, "publisher in url original not valid ", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if(checkUrl(url_altered)){
                altered_text=getContent(temp_provider,url_altered);
                tpAltered.setText(altered_text);
                lAltered = out_of_place.createGram(altered_text,1);
                positions_highlight_altered=new int[altered_text.length()];
                doc_altered= tpAltered.getStyledDocument();
                txtAltered.setText(praser.getTitle(url_altered));
            }else{
                JOptionPane.showMessageDialog(this, "publisher in url altered not valid ", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else if(e.getSource()==btnCheck){
            long start = System.currentTimeMillis();
            sbResult = new StringBuilder();
            checkSimilarity();
            tpAltered.setDocument(temp_blank);
            tpOriginal.setDocument(temp_blank);
            for(int i=10;i>=3;i--){
                getListGramSimilar(i);
                setHighLightSimilarity();
            }
            insert_index();
            tpAltered.setDocument(doc_altered);
            tpOriginal.setDocument(doc_origin);
            tpResult.setText(String.valueOf(sbResult));
            System.out.println("Time to update = " +
                    (System.currentTimeMillis() - start)+" millisecond");
        }
    }

    public boolean checkUrl(String url){
        boolean flag=false;
        int index =url.indexOf("http://");
        url =url.substring(index+7);
        index =url.indexOf(".");
        String provider=url.substring(0,index);
        if(provider.equals("vnexpress") || provider.equals("dantri") ||provider.equals("tuoitre")
                ||provider.equals("laodong") || provider.equals("phapluat") ||provider.equals("vietnamnet") ||
                provider.equals("congan") ||provider.equals("bongda") ||provider.equals("tiengphong") ){
            flag=true;
        }
        temp_provider=provider;
        return flag;
    }

    public String getContent(String name_provider,String url){
        String content="";
        if(name_provider.equals("vnexpress")){
            content= praser.parseVNEXPRESS(url);
        }else if(name_provider.equals("dantri")){
            content= praser.parseDANTRI(url);
        }else if(name_provider.equals("tuoitre")){
            content= praser.parseTUOITRE(url);
        }else if(name_provider.equals("laodong")){
            content= praser.parseLAODONG(url);
        }else if(name_provider.equals("phapluat")){
            content= praser.parsePHAPLUAT(url);
        }else if(name_provider.equals("vietnamenet")){
            content= praser.parseVIETNAMNET(url);
        }else if(name_provider.equals("congan")){
            content= praser.parseCONGAN(url);
        }else if(name_provider.equals("tiengphong")){
            content= praser.parseTIENPHONG(url);
        }else if(name_provider.equals("bongda")){
            content= praser.parseBONGDA(url);
        }
        content =content.replace(" ","  ");
        return  content;
    }

    private void checkSimilarity() {
        ArrayList<ArrayList<Gram>> documents = new ArrayList<ArrayList<Gram>>();
        documents.add(lOriginal);
        documents.add(lAltered);

        for(int i=0;i<lOriginal.size();i++){
            double temp=out_of_place.tfIdf(lOriginal,documents,lOriginal.get(i).getWord());
            lOriginal.get(i).setTfidf(temp);
        }
        Collections.sort(lOriginal, new GramComparatorTFIDF());


        for(int i=0;i<lAltered.size();i++){
            double temp=out_of_place.tfIdf(lAltered,documents,lAltered.get(i).getWord());
            lAltered.get(i).setTfidf(temp);
        }
        Collections.sort(lAltered, new GramComparatorTFIDF());
        double d12=out_of_place.computeDistance1(lOriginal,lAltered);
        double result=out_of_place.precentSimilarity(lOriginal.size(),lAltered.size(),d12);
        result = Math.floor(result * 100) / 100;
        sbResult.append("Mức độ tương tự giữa văn bản 1 và 2: "+result+" %");
        sbResult.append("\n");
    }


    public void getListGramSimilar(int k){
        lOriginal = out_of_place.createGram(original_text,k);
        lAltered = out_of_place.createGram(altered_text,k);
        for(int i=0;i<lOriginal.size();i++){
            String content=lOriginal.get(i).getWord();
            for(int j=0;j<lAltered.size();j++){
                if(content.equals(lAltered.get(j).getWord())){
                    list_gram_similar.add(lOriginal.get(i));
                    list_gram_similar_alt.add(lAltered.get(j));
                    break;
                }
            }
        }
//        sbResult.append(k+"-gram (% tương đồng trong văn bản gốc): "+ precent_gram(list_gram_similar.size(),k));
//        sbResult.append("\n");
    }

    public double precent_gram(int list_similar, int n_garm){
        String[] tokens = original_text.split("\\s+");
        double reuslt = ((list_similar * n_garm)/(double)tokens.length)*100;
        return reuslt;
    }




    public void setHighLightSimilarity(){
        for(int i=0;i<list_gram_similar.size();i++){
            String document=original_text;
            String word_in_gram1=list_gram_similar.get(i).getWord();
            int delete_index1 = word_in_gram1.indexOf("  ");
            int count=list_gram_similar.get(i).getCounter();
            int position=0;
            boolean flag=false;
            while(count!=0){
                int index = document.indexOf(word_in_gram1);
                if(!is_child_gram(position+index)){
                    positions_highlight[position+index]=tag_counter;
                    flag=true;
                }
                markHighLight(position+index,position+index+word_in_gram1.length(),1);
                position=position+index+delete_index1;
                document=document.substring(index+delete_index1);
                count--;
            }
            String document2=altered_text;
            String word_in_gram2=list_gram_similar_alt.get(i).getWord();
            int delete_index2 = word_in_gram2.indexOf("  ");
            int count2=list_gram_similar_alt.get(i).getCounter();
            int position2=0;
            while(count2!=0){
                int index = document2.indexOf(word_in_gram2);
                if(!is_child_gram_alter(position2+index)){
                    positions_highlight_altered[position2+index]=tag_counter;
                }
                markHighLight(position2+index,position2+index+word_in_gram2.length(),2);
                position2=position2+index+delete_index2;
                document2=document2.substring(index+delete_index2);
                count2--;
            }
            if(flag){
                tag_counter++;
            }
        }
    }


    public void insert_index(){
        SimpleAttributeSet keyWord = new SimpleAttributeSet();
        StyleConstants.setForeground(keyWord, Color.RED);
        StyleConstants.setBackground(keyWord, Color.YELLOW);
        StyleConstants.setBold(keyWord, true);
        StyleConstants.setSuperscript(keyWord,true);

        for(int i=0;i<positions_highlight.length;i++){
            int tag_index=positions_highlight[i];
            if(positions_highlight[i]!=0 && i!=0){
                try {
                    if(tag_index<10){
                        doc_origin.remove(i-1,1);
                        doc_origin.insertString(i-1, String.valueOf(tag_index), keyWord );
                    }else if(tag_index>=10 && tag_index<100){
                        doc_origin.remove(i-2,2);
                        doc_origin.insertString(i-2, String.valueOf(tag_index), keyWord );
                    }else{
                        doc_origin.remove(i-3,3);
                        doc_origin.insertString(i-3, String.valueOf(tag_index), keyWord );
                    }
                } catch (BadLocationException e) {
                    System.out.println("Invalid location insert index");
                }
            }
        }

        for(int i=0;i<positions_highlight_altered.length;i++){
            int tag_index=positions_highlight_altered[i];
            if(positions_highlight_altered[i]!=0 && i!=0){
                try {
                    if(tag_index<10){
                        doc_altered.remove(i-1,1);
                        doc_altered.insertString(i-1, String.valueOf(tag_index), keyWord );
                    }else if(tag_index>=10 && tag_index<100){
                        doc_altered.remove(i-2,2);
                        doc_altered.insertString(i-2, String.valueOf(tag_index), keyWord );
                    }else{
                        doc_altered.remove(i-3,3);
                        doc_altered.insertString(i-3, String.valueOf(tag_index), keyWord );
                    }
                } catch (BadLocationException e) {
                    System.out.println("Invalid location insert index");
                }
            }
        }
    }

    public boolean is_child_gram(int position){
        SimpleAttributeSet keyWord = new SimpleAttributeSet();
        StyleConstants.setBackground(keyWord, Color.CYAN);
        Element e=doc_origin.getCharacterElement(position);
        AttributeSet attributeNew = e.getAttributes();
        if(attributeNew.isEqual(keyWord)){
            return true;
        }else{
            return false;
        }
    }

    public boolean is_child_gram_alter(int position){
        SimpleAttributeSet keyWord = new SimpleAttributeSet();
        StyleConstants.setBackground(keyWord, Color.CYAN);
        Element e=doc_altered.getCharacterElement(position);
        AttributeSet attributeNew = e.getAttributes();
        if(attributeNew.isEqual(keyWord)){
            return true;
        }else{
            return false;
        }
    }

    public void markHighLight(int start, int end, int type) {
        SimpleAttributeSet keyWord = new SimpleAttributeSet();
        StyleConstants.setBackground(keyWord, Color.CYAN);
        if(type==1){
            doc_origin.setCharacterAttributes(start, end-start, keyWord, false);
        }else{
            doc_altered.setCharacterAttributes(start, end-start, keyWord, false);
        }
    }
}
