package View;

import javax.swing.*;

/**
 * Created by Duong Pham on 10/22/2016.
 */
public class Home extends JFrame {

    public Home(){

        setSize(1920,1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTabbedPane jtp=new JTabbedPane();
        jtp.add("DocumentTab",new DocumentTab());
        jtp.add("ArticleTab",new ArticleTab());
        add(jtp,"Center");

        setVisible(true);
    }


    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        Home h=new Home();
    }
}
