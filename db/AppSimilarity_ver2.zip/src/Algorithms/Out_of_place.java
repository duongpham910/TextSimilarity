package Algorithms;

import Model.Gram;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Duong Pham on 10/22/2016.
 */
public class Out_of_place {

    public StringBuilder sbText;

    public String Filter(String tam){
        String text = tam.replaceAll("\\`|\\~|\\!|\\@|\\#|\\$|\\%|\\^|\\&|\\*|\\(|"
                + "\\)|\\_|\\=|\\+|\\{|\\[|\\}|\\]|\\<|\\,|\\>|\\.|\\?|"
                + "\\/|\\;|\\:|\\–|\\d+", "");
        text =text.toLowerCase();
        return text;
    }

    public double tf(ArrayList<Gram> doc, String term) {
        double result = 0;
        int sum=0;
        for(int i=0;i<doc.size();i++){
            if(doc.get(i).getWord().equals(term)){
                result=doc.get(i).getCounter();
            }
            sum=sum+doc.get(i).getCounter();
        }
        return result / sum;
    }

    public double idf(ArrayList<ArrayList<Gram>> docs, String term) {
        double n = 0;
        for (int i=0;i<docs.size();i++) {
            for (int j=0;j<docs.get(i).size();j++) {
                Gram g=docs.get(i).get(j);
                if (term.equals(g.getWord())) {
                    n++;
                    break;
                }
            }
        }
        if(n>0){
            return Math.log(docs.size()/(n))+1;
        }else{
            return 1;
        }
    }

    public double tfIdf(ArrayList<Gram> doc, ArrayList<ArrayList<Gram>> docs, String term) {
        return tf(doc, term) * idf(docs, term);

    }

    public ArrayList<Gram> createGram(String text,int N){
        ArrayList<Gram> listGram = new ArrayList<Gram>();
        String[] tokens = text.split("\\s+");
        for (int i = 0; i < tokens.length - N + 1; i++) {
            String s = "";
            int start = i;
            int end = i + N;
            for (int j = start; j < end; j++) {
                s = s + "  " + tokens[j];
            }
            s=s.replaceAll("^\\s+", "");
            boolean flag = true;
            int counter = 0;
            if (listGram.size() != 0) {
                for (int k = 0; k < listGram.size(); k++) {
                    String temp = listGram.get(k).getWord();
                    if (temp.equals(s)) {
                        counter = listGram.get(k).getCounter();
                        counter++;
                        listGram.get(k).setCounter(counter);
                        flag = false;
                    }
                }
            }
            if (flag == true) {
                Gram g=new Gram(s,1,0);
                listGram.add(g);
            }
        }
        return listGram;
    }

    public ArrayList<Gram> createGram(String text){
        ArrayList<Gram> listGram = new ArrayList<Gram>();
        int N=1; // bi-gram
        System.out.println(text.length());
        String[] tokens = text.split("\\s+");
        for (int i = 0; i < tokens.length - N + 1; i++) {
            String s = "";
            int start = i;
            int end = i + N;
            for (int j = start; j < end; j++) {
                s = s + " " + tokens[j];
            }
            s=s.replaceAll("^\\s+", "");
            boolean flag = true;
            int counter = 0;
            if (listGram.size() != 0) {
                for (int k = 0; k < listGram.size(); k++) {
                    String temp = listGram.get(k).getWord();
                    if (temp.equals(s)) {
                        counter = listGram.get(k).getCounter();
                        counter++;
                        listGram.get(k).setCounter(counter);
                        flag = false;
                    }
                }
            }
            if (flag == true) {
                Gram g=new Gram(s,1,0);
                listGram.add(g);
            }
        }
        return listGram;
    }

    public void newText(){
        sbText=new StringBuilder();
    }

    public StringBuilder getSbText() {
        return sbText;
    }

    public double computeDistance1(ArrayList<Gram> doc1, ArrayList<Gram> doc2) {
        int DistanceMeasure=0;
        int max=0;
        int count=0;
        for(int i=0;i<doc2.size();i++){
            Gram g=doc2.get(i);
            boolean flag=true;
            for(int j=0;j<doc1.size();j++){
                Gram temp=doc1.get(j);
                if(g.getWord().equals(temp.getWord())){
                    int pos=Math.abs(j-i);
                    flag=false;
                    DistanceMeasure=DistanceMeasure+pos;
                    break;
                }
            }
            if(flag==true){
                count++;
            }
        }
        if(doc1.size()>doc2.size()){
            max=doc1.size();
        }else{
            max=doc2.size();
        }
        DistanceMeasure=DistanceMeasure+count*max;
        return DistanceMeasure;
    }

    public double precentSimilarity(int size1,int size2,double distance){
        int maxDistance=0;
        if(size1>size2){
            maxDistance=size1*size2;
        }else{
            maxDistance=size2*size2;
        }
        double result=(((maxDistance)-distance)/(maxDistance))*100;
        return result;
    }
}
