package Utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

/**
 * Created by Duong Pham on 11/11/2016.
 */
public class Praser {

    public String parseVNEXPRESS(String url){
        try {
            Document doc = Jsoup.connect(url).get();
            Elements content=doc.select("p[class=Normal]");
            StringBuilder sb=new StringBuilder();
            for(Element con: content){
                sb.append(con.text());
            }
            return String.valueOf(sb);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    public String parseDANTRI(String url){
        try {

            Document doc = Jsoup.connect(url).get();
            Element content=doc.getElementById("divNewsContent");
            return String.valueOf(content.select("p").text());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    public String parseTUOITRE(String url){
        try {

            Document doc = Jsoup.connect(url).get();
            Elements content=doc.getElementsByClass("fck");
            StringBuilder sb=new StringBuilder();
            for(Element con: content){
                sb.append(con.select("p").text());
            }
            return String.valueOf(sb);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String parseLAODONG(String url) {
        try {
            Document doc = Jsoup.connect(url).get();
            Elements content = doc.select("div[class=\"cms-body\"]");
            StringBuilder sb = new StringBuilder();
            for (Element con : content) {
                sb.append(con.text());
                if(!con.select("span").text().equals(null)){
                    con.select("span[class=\"cmt-count\"]").remove();
                    sb.append(con.select("span").text());
                }
            }
            return String.valueOf(sb);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String parsePHAPLUAT(String url) {
        try {

            Document doc = Jsoup.connect(url).get();
            Element content = doc.getElementById("main-detail");
            return String.valueOf(content.select("p").text());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String parseVIETNAMNET(String url) {
        try {

            Document doc = Jsoup.connect(url).get();
            Element content = doc.getElementById("ArticleContent");
            return String.valueOf(content.select("p").text());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String parseCONGAN(String url) {
        try {

            Document doc = Jsoup.connect(url).get();
            Element content = doc.getElementById("links");
            String sb=content.select("p").text();
            return String.valueOf(sb);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    public String parseBONGDA(String url) {
        try {
            Document doc = Jsoup.connect(url).get();
            Elements content = doc.select("div[class=\"exp_content\"]");
            StringBuilder sb = new StringBuilder();
            for (Element con : content) {
                sb.append(con.select("p").text());
            }
            return String.valueOf(sb);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    public String parseTIENPHONG(String url) {
        try {
            Document doc = Jsoup.connect(url).get();
            Element content = doc.getElementById("article-body");
            String sb=content.text();
            return String.valueOf(sb);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    public String getTitle(String url){
        String title="";
        try {
            Document doc = Jsoup.connect(url).get();
            title=doc.title();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return title;
    }
}
