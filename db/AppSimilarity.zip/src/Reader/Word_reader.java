package Reader;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

/**
 * Created by Duong Pham on 10/24/2016.
 */
public class Word_reader {

    public String Filter(String tam){
        String text = tam.replaceAll("\\`|\\~|\\!|\\@|\\#|\\$|\\%|\\^|\\&|\\*|\\(|"
                + "\\)|\\_|\\=|\\+|\\{|\\[|\\}|\\]|\\<|\\,|\\>|\\.|\\?|"
                + "\\/|\\;|\\:|\\–|\\d+", "");
        text =text.toLowerCase();
        return text;
    }

    public  String readDocFile(String fileName) {
        StringBuilder sb=new StringBuilder();
        try {
            File file = new File(fileName);
            FileInputStream fis = new FileInputStream(file.getAbsolutePath());

            HWPFDocument doc = new HWPFDocument(fis);

            WordExtractor we = new WordExtractor(doc);

            String[] paragraphs = we.getParagraphText();

            //System.out.println("Total no of paragraph " + paragraphs.length);
            for (String para : paragraphs) {
                para = Filter(para);
                sb.append(para.toString());
            }
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return standardize_string(String.valueOf(sb));
    }

    public String readDocxFile(String fileName) {
        StringBuilder sb=new StringBuilder();
        try {
            File file = new File(fileName);
            FileInputStream fis = new FileInputStream(file.getAbsolutePath());

            XWPFDocument document = new XWPFDocument(fis);

            List<XWPFParagraph> paragraphs = document.getParagraphs();

            //System.out.println("Total no of paragraph " + paragraphs.size());
            for (XWPFParagraph para : paragraphs) {
                String temp = para.getText();
                temp =Filter(temp);
                sb.append(temp);
            }
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return standardize_string(String.valueOf(sb));
    }

    public String standardize_string(String text){
        StringTokenizer st=new StringTokenizer(text);
        StringBuilder b=new StringBuilder();
        while(st.hasMoreTokens()){
            String tam=st.nextToken();
            b.append(tam);
            b.append(" ");
        }
        return String.valueOf(b);
    }
}
