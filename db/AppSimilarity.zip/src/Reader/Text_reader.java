package Reader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Created by Duong Pham on 10/24/2016.
 */
public class Text_reader {

    public String Filter(String tam){
        String text = tam.replaceAll("\\`|\\~|\\!|\\@|\\#|\\$|\\%|\\^|\\&|\\*|\\(|"
                + "\\)|\\_|\\=|\\+|\\{|\\[|\\}|\\]|\\<|\\,|\\>|\\.|\\?|"
                + "\\/|\\;|\\:|\\–|\\d+", "");
        text =text.toLowerCase();
        return text;
    }

    public String readFileText(String fileName){
        StringBuilder sb=new StringBuilder();
        try {
            Scanner input=new Scanner(new FileInputStream(fileName));
            while(input.hasNextLine()){
                String text=input.nextLine();
                text=Filter(text);
                sb.append(text);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return standardize_string(String.valueOf(sb));
    }

    public String standardize_string(String text){
        StringTokenizer st=new StringTokenizer(text);
        StringBuilder b=new StringBuilder();
        while(st.hasMoreTokens()){
            String tam=st.nextToken();
            b.append(tam);
            b.append(" ");
        }
        return String.valueOf(b);
    }
}
