package View;

import Algorithms.Out_of_place;
import Model.Gram;
import Model.GramComparatorTFIDF;
import Reader.PDF_reader;
import Reader.Text_reader;
import Reader.Word_reader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Arc2D;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.*;
import javax.swing.text.*;

/**
 * Created by Duong Pham on 10/22/2016.
 */
public class Home extends JFrame implements ActionListener {

    public String original_text = "Original text";
    public String altered_text = "Rewrite text";
    public JButton btnSelectOriginal = new JButton("Original document");
    public JButton btnSelectAltered = new JButton("Altered (rewrite) copy");
    public JButton btnCheck = new JButton("Check");
    public JFileChooser fileopen = new JFileChooser();
    public Out_of_place out_of_place = new Out_of_place();
    public ArrayList<Gram> lOriginal;
    public ArrayList<Gram> lAltered;

    public JTextPane tpOriginal = new JTextPane();
    public JTextPane tpAltered = new JTextPane();
    public JTextPane tpResult =new JTextPane();

    private Highlighter.HighlightPainter cyanPainter;
    private Highlighter.HighlightPainter redPainter;

    public ArrayList<Gram> list_gram_similar = new ArrayList<Gram>();
    public ArrayList<Gram> list_gram_similar_alt = new ArrayList<Gram>();

    public String temp_document;
    public StringBuilder sbResult;

    public Home(){
        setSize(1920,1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel p1=new JPanel();
        btnSelectOriginal.addActionListener(this);
        btnSelectAltered.addActionListener(this);
        btnCheck.addActionListener(this);
        p1.add(btnSelectOriginal);
        p1.add(btnSelectAltered);
        p1.add(btnCheck);

        JPanel p2=new JPanel(new GridLayout(0,2));
        p2.add(new JScrollPane(tpOriginal));
        p2.add(new JScrollPane(tpAltered));

        fileopen.setDialogTitle("Choose your file!");

        JPanel p3=new JPanel();
        GridBagLayout gridBagLayout=new GridBagLayout();
        p3.setLayout(gridBagLayout);
        GridBagConstraints gridBagConstraints=new GridBagConstraints();



        gridBagConstraints.gridx=0;
        gridBagConstraints.gridy=0;
        gridBagConstraints.insets=new Insets(10,10,10,10);
        JScrollPane jp=new JScrollPane(tpResult);
        jp.setPreferredSize(new Dimension(1280, 150));
        p3.add(jp,gridBagConstraints);


        cyanPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.cyan);
        redPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.red);

        add(p1,"North");
        add(p2,BorderLayout.CENTER);
        add(p3,"South");
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==btnSelectOriginal){
            tpOriginal.setText("waiting until process finish");
            fileopen.showOpenDialog(null);
            lOriginal = getListGram(fileopen.getSelectedFile().getAbsolutePath());
            tpOriginal.setText(temp_document);
            original_text=temp_document;
        }else if(e.getSource()==btnSelectAltered){
            tpAltered.setText("waiting until process finish");
            fileopen.showOpenDialog(null);
            lAltered = getListGram(fileopen.getSelectedFile().getAbsolutePath());
            tpAltered.setText(temp_document);
            altered_text=temp_document;
        }else if(e.getSource()==btnCheck){
            sbResult = new StringBuilder();
            checkSimilarity();
            for(int i=5;i>=3;i--){
                getListGramSimilar(i);
                setHighLightSimilarity(i);
            }
            tpResult.setText(String.valueOf(sbResult));
        }
    }


    public ArrayList<Gram> getListGram(String file_path){
        String file_type=check_file_type(file_path);
        String text="";
        switch (file_type){
            case "doc":
                text = readDoc(file_path);
                break;
            case "docx":
                text = readDocx(file_path);
                break;
            case "pdf":
                text = readPdf(file_path);
                break;
            case "txt":
                text = readText(file_path);
                break;
            default:
                break;
        }
        temp_document=text;
        return out_of_place.createGram(text);
    }

    public String check_file_type(String file_path){
        int index=file_path.indexOf(".");
        String file_type=file_path.substring(index+1);
        return file_type;
    }

    public String readText(String file_path){
        Text_reader tr=new Text_reader();
        String result = tr.readFileText(file_path);
        return result;
    }

    public String readDoc(String file_path){
        Word_reader wr=new Word_reader();
        String result =wr.readDocFile(file_path);
        return  result;
    }

    public String readDocx(String file_path){
        Word_reader wr=new Word_reader();
        String result =wr.readDocxFile(file_path);
        return  result;
    }

    public String readPdf(String file_path){
        PDF_reader pr=new PDF_reader();
        pr.setFilePath(file_path);
        String result="";
        try {
            result = pr.ToText();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private void checkSimilarity() {
        ArrayList<ArrayList<Gram>> documents = new ArrayList<ArrayList<Gram>>();
        documents.add(lOriginal);
        documents.add(lAltered);

        for(int i=0;i<lOriginal.size();i++){
            double temp=out_of_place.tfIdf(lOriginal,documents,lOriginal.get(i).getWord());
            lOriginal.get(i).setTfidf(temp);
        }
        Collections.sort(lOriginal, new GramComparatorTFIDF());


        for(int i=0;i<lAltered.size();i++){
            double temp=out_of_place.tfIdf(lAltered,documents,lAltered.get(i).getWord());
            lAltered.get(i).setTfidf(temp);
        }
        Collections.sort(lAltered, new GramComparatorTFIDF());
        double d12=out_of_place.computeDistance1(lOriginal,lAltered);
        sbResult.append("Mức độ tương tự giữa văn bản 1 và 2: "+out_of_place.precentSimilarity(lOriginal.size(),lAltered.size(),d12));
        sbResult.append("\n");
    }

    public void getListGramSimilar(int k){
        lOriginal = out_of_place.createGram(tpOriginal.getText(),k);
        lAltered = out_of_place.createGram(tpAltered.getText(),k);
        for(int i=0;i<lOriginal.size();i++){
            String content=lOriginal.get(i).getWord();
            for(int j=0;j<lAltered.size();j++){
                if(content.equals(lAltered.get(j).getWord())){
                    list_gram_similar.add(lOriginal.get(i));
                    list_gram_similar_alt.add(lAltered.get(j));
                    break;
                }
            }
        }
        sbResult.append(k+"-gram (% tương đồng trong văn bản gốc):"+ precent_gram(list_gram_similar.size(),k));
        sbResult.append("\n");
    }

    public double precent_gram(int list_similar, int n_garm){
        String[] tokens = tpOriginal.getText().split("\\s+");
        double reuslt = ((list_similar * n_garm)/(double)tokens.length)*100;
        return reuslt;
    }


    public void markHighLight(int start, int end, int type, int color) {
        try {
            if(type==1){
                if(color==3){
                    tpOriginal.getHighlighter().addHighlight(start, end, DefaultHighlighter.DefaultPainter);
                }else if(color==4){
                    tpOriginal.getHighlighter().addHighlight(start, end, redPainter);
                }else{
                    tpOriginal.getHighlighter().addHighlight(start, end, cyanPainter);
                }
            }else{
                if(color==3){
                    tpAltered.getHighlighter().addHighlight(start, end, DefaultHighlighter.DefaultPainter);
                }else if(color==4){
                    tpAltered.getHighlighter().addHighlight(start, end, redPainter);
                }else{
                    tpAltered.getHighlighter().addHighlight(start, end, cyanPainter);
                }
            }
        } catch (BadLocationException ble) {

        }
    }

    public void setHighLightSimilarity(int color){

        for(int i=0;i<list_gram_similar.size();i++){
            String document=original_text;
            String word_in_gram1=list_gram_similar.get(i).getWord();
            int delete_index1 = word_in_gram1.indexOf(" ");
            int count=list_gram_similar.get(i).getCounter();
            int position=0;
            while(count!=0){
                int index = document.indexOf(word_in_gram1);
                markHighLight(position+index,position+index+word_in_gram1.length(),1, color);
                position=position+index+delete_index1;
                document=document.substring(index+delete_index1);
                count--;
            }

            String document2=altered_text;
            String word_in_gram2=list_gram_similar_alt.get(i).getWord();
            int delete_index2 = word_in_gram2.indexOf(" ");
            int count2=list_gram_similar_alt.get(i).getCounter();
            int position2=0;
            while(count2!=0){
                int index = document2.indexOf(word_in_gram2);
                markHighLight(position2+index,position2+index+word_in_gram2.length(),2, color);
                position2=position2+index+delete_index2;
                document2=document2.substring(index+delete_index2);
                count2--;
            }
        }
    }


    public static void main(String[] args) {
        Home h=new Home();
    }
}
